<?php
include 'config.php';

// Occupancy Rate
$rooms = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) AS total_rooms FROM room"));
$occupied = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) AS occupied_rooms FROM room WHERE status='Booked'"));
$occupancy_rate = ($occupied['occupied_rooms'] / $rooms['total_rooms']) * 100;

// Monthly Revenue
$monthly = mysqli_query($conn,"
  SELECT MONTHNAME(booked_at) AS month, SUM(pay_amount) AS revenue
  FROM booking
  GROUP BY MONTH(booked_at)
  ORDER BY MONTH(booked_at)
");

// Service Request Breakdown
$service = mysqli_query($conn,"
  SELECT type, COUNT(*) AS count
  FROM service_request
  GROUP BY type
");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Manager Dashboard</title>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <style>
    body {font-family:'Segoe UI',Arial;background-color:#f4f6f9;margin:0;padding:20px;}
    h1 {color:#007BFF;text-align:center;}
    .charts {display:flex;flex-wrap:wrap;justify-content:center;gap:40px;margin-top:30px;}
    canvas {background:#fff;border-radius:10px;box-shadow:0 0 10px rgba(0,0,0,0.1);padding:20px;}
  </style>
</head>
<body>
<?php include 'sidebar.php'; ?>
<div class="mgr-layout">
<div class="mgr-main" style="padding:24px;">
  <h1>Hotel Manager Dashboard — Charts</h1>

  <div class="charts">
    <div>
      <h3 style="text-align:center;">Occupancy Rate</h3>
      <canvas id="occupancyChart" width="300" height="300"></canvas>
    </div>

    <div>
      <h3 style="text-align:center;">Monthly Revenue Trend</h3>
      <canvas id="revenueChart" width="400" height="300"></canvas>
    </div>

    <div>
      <h3 style="text-align:center;">Service Request Breakdown</h3>
      <canvas id="serviceChart" width="300" height="300"></canvas>
    </div>
  </div>

  <script>
    // Occupancy Pie Chart
    const occData = {
      labels: ['Occupied', 'Available'],
      datasets: [{
        data: [<?php echo $occupied['occupied_rooms']; ?>, <?php echo $rooms['total_rooms'] - $occupied['occupied_rooms']; ?>],
        backgroundColor: ['#007BFF', '#ccc']
      }]
    };
    new Chart(document.getElementById('occupancyChart'), {type:'pie', data:occData});

    // Monthly Revenue Bar Chart
    const revLabels = [<?php while($row=mysqli_fetch_assoc($monthly)){echo "'".$row['month']."',";} ?>];
    const revData = [<?php
      mysqli_data_seek($monthly,0);
      while($row=mysqli_fetch_assoc($monthly)){echo $row['revenue'].",";}
    ?>];
    new Chart(document.getElementById('revenueChart'), {
      type:'bar',
      data:{
        labels:revLabels,
        datasets:[{label:'Revenue (৳)', data:revData, backgroundColor:'#28a745'}]
      },
      options:{scales:{y:{beginAtZero:true}}}
    });

    // Service Request Pie Chart
    const srvLabels = [<?php while($row=mysqli_fetch_assoc($service)){echo "'".$row['type']."',";} ?>];
    const srvData = [<?php
      mysqli_data_seek($service,0);
      while($row=mysqli_fetch_assoc($service)){echo $row['count'].",";}
    ?>];
    new Chart(document.getElementById('serviceChart'), {
      type:'doughnut',
      data:{
        labels:srvLabels,
        datasets:[{data:srvData, backgroundColor:['#007BFF','#ffc107','#28a745','#dc3545','#6f42c1']}]
      }
    });
  </script>
</div></div>
</body>
</html>
